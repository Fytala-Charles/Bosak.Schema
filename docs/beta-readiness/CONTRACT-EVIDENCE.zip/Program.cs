// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 17 November 2026
// PURPOSE              : Characterizes published API behavior safely for the beta contract audit.
// SPECIAL NOTES        : Bounded native decimal profile; published Core 1.81.2; no general XSD conformance claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 17-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Collections;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.Schema;

var records = new List<object>();
var directory = Path.Combine(Path.GetTempPath(), "bosak-beta-audit-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(directory);
var compiler = SchemaServices.CreateSchemaCompiler();
var service = SchemaServices.CreateValidationService();
ICompiledSchema Compile(string xml)
{
    using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml));
    return compiler.Compile(input, new Uri("file:///beta-audit/schema.xsd"), SchemaCompileOptions.Default(XsdLanguageVersion.Xsd11));
}
void Observe(string name, Func<object> work)
{
    try { records.Add(new { name, result = work(), exception = (string?)null }); }
    catch (Exception error) { records.Add(new { name, result = (object?)null, exception = error.GetType().FullName }); }
}
try
{
    Observe("legacy-unmatched-root-no-assertions", () =>
    {
        var schema = Compile("<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:element name='order' type='xs:decimal'/></xs:schema>");
        var result = service.Validate(schema, XElement.Parse("<unexpected/>"));
        return new { compileDiagnostics = schema.Diagnostics.Count, result.IsValid, diagnostics = result.Diagnostics.Count };
    });
    Observe("legacy-compile-diagnostic-not-propagated", () =>
    {
        var schema = Compile("<not-schema/>");
        var result = service.Validate(schema, XElement.Parse("<unexpected/>"));
        return new { compileDiagnostics = schema.Diagnostics.Count, result.IsValid, diagnostics = result.Diagnostics.Count };
    });
    Observe("compiled-collections-runtime-mutability", () =>
    {
        var schema = Compile("<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'/>");
        return new { assertions = schema.Assertions.GetType().FullName, writableList = schema.Assertions is IList list && !list.IsReadOnly };
    });
    Observe("xslt-directory-parent-hint", () =>
    {
        var allowed = Path.Combine(directory, "schemas");
        Directory.CreateDirectory(allowed);
        File.WriteAllText(Path.Combine(directory, "outside.xsd"), "AUDIT-MARKER");
        var xslt = SchemaAwareXslt.CreateCompiler(allowed);
        using var stream = xslt.SchemaResolver!("", new[] { "../outside.xsd" });
        return new { openedOutsideDirectory = stream is not null, marker = stream is null ? null : new StreamReader(stream).ReadToEnd() };
    });
    Observe("resolver-prefix-is-text-prefix", () =>
    {
        var allowed = Path.Combine(directory, "allowed");
        var sibling = Path.Combine(directory, "allowed-sibling");
        Directory.CreateDirectory(sibling);
        var target = Path.Combine(sibling, "sample.xsd");
        File.WriteAllText(target, "AUDIT-MARKER");
        var resolver = new SecureSchemaResolver(new SchemaResolutionPolicy(true, false, false, 1024, new[] { new Uri(allowed).AbsoluteUri }));
        using var stream = resolver.Open(new Uri(target));
        return new { openedSibling = stream is not null };
    });
}
finally
{
    // Delete only exact paths created by this diagnostic, never recursive user paths.
    foreach (var file in new[] { Path.Combine(directory, "outside.xsd"), Path.Combine(directory, "allowed-sibling", "sample.xsd") })
        if (File.Exists(file)) File.Delete(file);
    foreach (var folder in new[] { Path.Combine(directory, "schemas"), Path.Combine(directory, "allowed-sibling"), directory })
        if (Directory.Exists(folder)) Directory.Delete(folder, false);
}
Console.WriteLine(JsonSerializer.Serialize(new { package = "Bosak.Schema/0.5.0-alpha.0.7", records }, new JsonSerializerOptions { WriteIndented = true }));

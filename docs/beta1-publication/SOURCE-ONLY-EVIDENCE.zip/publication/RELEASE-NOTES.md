Bosak.Schema 0.5.0-beta.1 is the first beta of the bounded, synchronous native decimal-session API for .NET 10. Schema is Apache-2.0 and requires no activation key or subscription.

Install from [NuGet.org](https://www.nuget.org/packages/Bosak.Schema/0.5.0-beta.1):

```sh
dotnet add package Bosak.Schema --version 0.5.0-beta.1
```

The attached `.nupkg` is the repository-signed package downloaded from NuGet.org and independently verified against the approved hosted preparation. `SHA256SUMS.txt` records its checksum.

### Included in this beta

- Owned `NativeDecimalSession` and `NativeDecimalDocument` APIs with explicit capacities, assessment context, detached results and XML export.
- Finite decimal-only schema assessment, with distinct Valid, Invalid and Unsupported results.
- Opt-in restricted schema file resolution and a controlled schema-aware XSLT compiler factory. These require stable host-owned filesystem paths.
- Immutable compiler-owned descriptor snapshots.
- Legacy validation entry points refuse schemas containing compile diagnostics. A clean legacy validation result remains scoped to the implemented assertion/facet checks.

### Scope and compatibility

This beta covers the accepted bounded decimal-session contract. It does not provide complete XSD 1.1 validation. The native profile excludes namespaces, attributes, broader datatypes, nil/list/union and arbitrary XPath. General Core provider/session acceptance and production performance SLAs remain outside this release. Future breaking beta changes will be reviewed and announced.

The package targets `net10.0` and declares minimum Core dependency version 1.81.2; qualification used the published 1.81.2 packages. Compatibility with every later Core version is not implied.

See the [native decimal API guide](https://github.com/Fytala-Charles/Bosak.Schema/blob/2a5abf6fb663313dc32bfeca5bbb8740bbe987ae/docs/NATIVE-DECIMAL-PUBLIC-API.md), [restricted resolution guide](https://github.com/Fytala-Charles/Bosak.Schema/blob/2a5abf6fb663313dc32bfeca5bbb8740bbe987ae/docs/RESTRICTED_RESOLUTION.md), and [bounded contract review](https://github.com/Fytala-Charles/Bosak.Schema/blob/2a5abf6fb663313dc32bfeca5bbb8740bbe987ae/docs/BETA_CONTRACT_REVIEW.md). These guides retain their original checkpoint dates and receipts.

### Verification

The release passed 345 source tests, 33 package-only consumer tests, and retained legacy124/published-alpha23 control and replacement lanes. Only the Schema DLL changed in the retained layouts. All nine Core dependencies passed signature and archive/cache/runtime payload identity checks. These test catalogs overlap.

After publication, the NuGet repository signature passed, every approved package payload entry matched byte-for-byte, and a fresh registry-only consumer passed all 33 cases.

Product tag `v0.5.0-beta.1` resolves to `2a5abf6fb663313dc32bfeca5bbb8740bbe987ae`. [Hosted preparation](https://github.com/Fytala-Charles/Bosak.Schema/actions/runs/44244606595) and [NuGet publication](https://github.com/Fytala-Charles/Bosak.Schema/actions/runs/44245557198).

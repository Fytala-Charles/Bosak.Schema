// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 18 November 2026
// PURPOSE              : Exercises the published bounded Schema beta with the public invoice fixture.
// SPECIAL NOTES        : Representative package-only consumer diagnostic; not production acceptance.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 18-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text.Json;
using System.Xml.Linq;
using Bosak.Schema;

try
{
    var schema = File.ReadAllText(Path.Combine(args[0], "invoice.xsd"));
    var xml = File.ReadAllText(Path.Combine(args[0], "invoice.xml"));
    var options = new NativeDecimalSessionOptions(256, 256, 1, 4, 1, 256, 256);
    var context = new NativeDecimalAssessmentContext(new DateTimeOffset(2026, 11, 18, 12, 0, 0, TimeSpan.Zero), 60);
    var creation = NativeDecimalSession.Create(schema, options);
    Require(creation.Outcome == NativeDecimalOutcome.Valid && creation.Value is not null, "invoice schema creation");
    using var session = creation.Value!;
    var assessment = session.Assess(xml, context);
    Require(assessment.Outcome == NativeDecimalOutcome.Valid && assessment.Value is not null, "invoice assessment");
    var document = assessment.Value!;
    var first = document.ReadDecimal(0);
    var second = document.ReadDecimal(1);
    Require(document.DecimalCount == 2 && first.ToInvariantString(256) == "10" && second.ToInvariantString(256) == "5", "exact scalars");
    var exported = document.ExportXml();
    Require(XNode.DeepEquals(XDocument.Parse(xml).Root, XDocument.Parse(exported).Root), "detached XML tree");
    Expect<InvalidOperationException>(() => session.Assess(xml, context));
    document.Dispose();
    Expect<ObjectDisposedException>(() => document.ReadDecimal(0));
    var invalid = session.Assess("<invoice><amount>10</amount></invoice>", context);
    Require(invalid.Outcome == NativeDecimalOutcome.Invalid && invalid.Value is null, "assertion violation");
    var unsupported = session.Assess(xml.Replace("<invoice ", "<invoice currency='EUR' ", StringComparison.Ordinal), context);
    Require(unsupported.Outcome == NativeDecimalOutcome.Unsupported && unsupported.Value is null, "attribute exclusion");
    var namespaced = NativeDecimalSession.Create(schema.Replace("version=\"1.1\"", "version=\"1.1\" targetNamespace=\"urn:invoice\"", StringComparison.Ordinal), options);
    Require(namespaced.Outcome == NativeDecimalOutcome.Unsupported && namespaced.Value is null, "namespace exclusion");
    using var canceled = new CancellationTokenSource();
    canceled.Cancel();
    Expect<OperationCanceledException>(() => session.Assess(xml, context, canceled.Token));
    using var recovered = session.Assess(xml, context).Value!;
    Require(recovered.DecimalCount == 2, "recovery after refusals and cancellation");
    session.Dispose();
    Require(first.ToInvariantString(256) == "10" && second.ToInvariantString(256) == "5" && XDocument.Parse(exported).Root!.Name.LocalName == "invoice", "detached outputs after session disposal");
    File.WriteAllText(args[1], JsonSerializer.Serialize(new { passed = true, version = "0.5.0-beta.1", representativeOnly = true, productionAcceptance = false, exactScalars = new[] { "10", "5" }, detachedXmlTreePreserved = true, quotaAndClosedAccessRefused = true, assertionViolation = invalid.Outcome.ToString(), attributeExclusion = unsupported.Outcome.ToString(), namespaceExclusion = namespaced.Outcome.ToString(), preCancellationAndRecovery = true, detachedOutputsSurviveDisposal = true }, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine("PASS: published invoice workflow, exact scalars/export, supported violation, exclusions, quota/disposal and pre-cancel recovery.");
    return 0;
}
catch (Exception error)
{
    Console.Error.WriteLine("Invoice trial failed safely: " + error.GetType().Name + ": " + error.Message);
    return 1;
}

static void Require(bool condition, string stage)
{
    if (!condition) throw new InvalidOperationException(stage);
}

static void Expect<T>(Action action) where T : Exception
{
    try { action(); }
    catch (T) { return; }
    throw new InvalidOperationException("Expected " + typeof(T).Name);
}

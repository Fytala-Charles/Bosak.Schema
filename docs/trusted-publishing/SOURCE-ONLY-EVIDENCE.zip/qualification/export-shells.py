from pathlib import Path
import sys,json
p=Path(__file__).parent;sys.path.insert(0,str(p/'yaml-parser'))
import yaml
root=Path(r'D:/Development/Bosak/.worktrees/Schema.TrustedPublishing');out=p/'shells';out.mkdir(exist_ok=True)
rows=[]
for name in ['build.yml','release.yml']:
 data=yaml.load((root/'.github/workflows'/name).read_text(encoding='utf-8'),Loader=yaml.BaseLoader)
 for job,details in data['jobs'].items():
  for index,step in enumerate(details['steps']):
   if 'run' not in step:continue
   file=f'{name}-{job}-{index}.ps1';(out/file).write_text(step['run'],encoding='utf-8');rows.append({'workflow':name,'job':job,'step':step.get('name',str(index)),'file':file})
(p/'SHELLS.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print('Exported',len(rows),'PowerShell bodies for parser-only validation.')

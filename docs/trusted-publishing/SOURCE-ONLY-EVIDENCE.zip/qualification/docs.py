from pathlib import Path
import json
root=Path(r'D:/Development/Bosak/.worktrees/Schema.TrustedPublishing')
def save(p,s):(root/p).write_text(s,encoding='utf-8')
note='''A [trusted-publishing route](TRUSTED_PUBLISHING.md) is prepared locally following the owner's selection. The new release workflow is manual and preparation-only by default; its publisher verifies a successful same-repository/main/first-attempt preparation, the exact reviewed manifest/package and registry absence before OIDC login and again before one push. Product source/version/Core dependencies are unchanged. No workflow dispatch, policy/account update, login or publication has occurred. A hosted preparation will create its own artifact/digest for review; the earlier local package remains preserved.'''
for path,heading in [('docs/ARCHITECTURE.md','## 5. Validation and Extensibility'),('docs/FEATURE_REQUESTS.md','## 1. Registry'),('docs/INTEGRATION.md','## 1. Dependency and Availability')]:
 p=root/path;s=p.read_text(encoding='utf-8');assert heading in s;save(path,s.replace(heading,heading+'\n\n'+note,1))
p=root/'ROADMAP.md';s=p.read_text(encoding='utf-8');save('ROADMAP.md',s.replace('## 2. Next Milestones','## 2. Next Milestones\n\n'+note.replace('(TRUSTED_PUBLISHING.md)','(docs/TRUSTED_PUBLISHING.md)'),1))
p=root/'README.md';s=p.read_text(encoding='utf-8');needle='NuGet packaging uses the separate [package README](docs/NUGET_README.md) with absolute HTTPS links; this repository overview retains its normal local documentation links.';assert needle in s;save('README.md',s.replace(needle,needle+' See [trusted-publishing preparation](docs/TRUSTED_PUBLISHING.md) for the manual prerelease delivery route.'))
p=root/'docs/FEATURE_REQUESTS.md';s=p.read_text(encoding='utf-8');needle='| Complete XSD 1.1 structural validation |';s=s.replace(needle,'| NuGet trusted publishing | Local workflow/controller candidate; not configured or dispatched | Manual prepare/publish separation;41 refusal controls and real artifact rehearsal; profile/user policy and publication approval remain separate |\n'+needle,1);save('docs/FEATURE_REQUESTS.md',s)
p=root/'AGENTS.md';s=p.read_text(encoding='utf-8');s+='''

## Release automation controls

Workflow-only release controls are separate from the 272 product/source test cases. Run `python -m unittest discover -s .github/scripts -p test_schema_release.py` and `node --test .github/scripts/test-schema-source-run.cjs`. They use synthetic artifacts and mocked GitHub/network responses; they do not log in or push. `.github/workflows/release.yml` admits only manually selected main preparation/publication for the recorded first prerelease, with OIDC permission confined to the publish job. Neither passing controls nor a prepared artifact authorizes registry publication. Keep the product source/Core pins and earlier immutable receipts unchanged.
''';save('AGENTS.md',s)
p=root/'docs/AGENT_HANDOVER.md';save('docs/AGENT_HANDOVER.md','''# Schema trusted-publishing route prepared locally - 17 November 2026

Last updated: 2026-11-17

Owner selected NuGet trusted publishing after metadata inspection found Schema has no secrets/variables/environment or publisher workflow configured. Isolated .worktrees/Schema.TrustedPublishing / ci/schema-trusted-publishing based on merged1783d1a. '''+note+'''

Release workflow/controller/tests are uncommitted; explicit commit/push instruction is still required by AGENTS. Product src/tests/global.json and package dependencies unchanged. Build0warnings/errors and272product cases pass;19Python+22Node=41separatecontrol cases pass. Release/build YAML parses;11PowerShell bodies parse without execution. A local rehearsal against the actual preserved89,520-byte0.5alpha0.7package verifies source, package/9Core signatures/payloads,272+23case receipts,124legacy cases per lane,seal/verify andregistryGET. It uses all-zero controller placeholder, has no hosted run, and is explicitly ineligible for publication. PyYAML6.0.3 installed only under ignored Core packet for local syntax validation; no product dependency.

Current source/version allowlist is1783d1a99b37e206b10592c24b3a5fa3ac126969/0.5.0-alpha.0.7, legacybaselinec953ebe, SDK10.0.301, Core1.81.2. Manual publish consumes a first-attempt successful release preparation run and exactmanifesthash; no rebuild, duplicate suppression, broad package glob or long-lived APIkey. VariableNUGET_USER (NuGet profile name) and NuGet policy must be configured by owner/explicit authorized action. Policy fields:ownerFytala-Charles/repoBosak.Schema/workflowrelease.yml/environmentblank, packageBosak.Schema, pushnew+versions scope. See docs/TRUSTED_PUBLISHING.md. No trust-policy/account or GitHub setting changes made; no credential requested/read.

Next: review concrete workflow/source-only evidence payload and request explicit commit/push/PR approval. After merge+checks, dispatch preparation only, download and independently review new hosted artifact/manifest, then ask explicit publication approval for that exact run/hash before login/push. Earlier localpackageSHA d9f3ed5897ce30c6069e72a8e651e3648d132251a3c6ef232d8aa946dd3428d6 remains sealed; hosted rebuild has a distinct provenance/digest and cannot be silently substituted. No tag/release/publication/profilefreeze acceptance. Rawlogs/rehearsal/parser/controllers .guard-tmp/schema-trusted-publishing-20261117; source-only dossier docs/trusted-publishing. Originalownercheckouts andsealedpackets preserved.

---

'''+p.read_text(encoding='utf-8'))
save('.kimi/HANDOVER.md','''# Public Schema session state

See [canonical handover](../docs/AGENT_HANDOVER.md) and [trusted-publishing setup](../docs/TRUSTED_PUBLISHING.md). Owner-selected OIDC route is prepared locally; no account configuration, workflow dispatch, login or push performed. Product remains272cases/Core1.81.2;41separate release controls pass. Commit/push and exact hosted artifact publication require separate explicit approval.

Last updated: 2026-11-17
''')
save('docs/TRUSTED_PUBLISHING.md','''# Schema NuGet trusted-publishing setup

17 November 2026. Local automation proposal, not a configured or executed publisher. The owner selected this route; publication of any package remains a separate decision. [Scope and evidence](trusted-publishing/README.md).

## Owner configuration after workflow review

Following [Microsoft's NuGet trusted-publishing setup](https://learn.microsoft.com/en-us/nuget/nuget-org/trusted-publishing), use the NuGet account or organization intended to own Bosak.Schema. Confirm rights to create/publish that package ID; a404 registry response does not establish those rights.

| NuGet policy field | Value for this workflow |
|---|---|
| Repository owner | Fytala-Charles |
| Repository | Bosak.Schema |
| Workflow file | release.yml (filename only) |
| Environment | Leave blank; this workflow declares no GitHub environment |
| Package pattern | Bosak.Schema |
| Scopes | Push new packages and push new versions for this package |
| Policy owner | The intended individual/organization NuGet owner; confirm active rights/status |

Set the **NUGET_USER repository Actions variable** to that NuGet profile name, not an email/password/API key. This is an account identifier, not the publishing credential. Do not send a password, API key or OIDC token in chat. The policy belongs to the Schema repository; Core's existing policy does not authorize this different repository. No policy or variable has been created by the local implementation.

The workflow obtains a short-lived key using NuGet/login@v1 only in the publish job. Only that job has id-token:write. Do not rename release.yml without reviewing the NuGet policy. If an environment is introduced later, its name must also match the policy; none is configured by this candidate.

## Preparation, review, publication

1. After reviewing/merging the workflow and completing hosted build/test/docs/controls, dispatch **Schema release** on main with publish=false. Preparation is the default and performs no NuGet login/push.
2. The first controller admits only immutable accepted product source1783d1a99b37e206b10592c24b3a5fa3ac126969 and expected0.5.0-alpha.0.7, without a Version override. It runs272source cases,23package-only cases, baseline/candidate124legacy cases each, nine Core1.81.2 signature and payload checks, then seals one package/manifest. These catalogs overlap and are not additive.
3. Download the successful first-attempt preparation run's schema-nuget artifact, verify its artifact digest, manifest source/controller/product identities, exact package bytes, case receipts and exclusions. Review the resulting manifest SHA-256 and package SHA-256. Hosted builds may differ from the earlier locally prepared archive; preserve both receipts and obtain a new exact-artifact decision. Never assert that a rebuild retained the local digest without checking it.
4. Obtain explicit publication approval for the selected run, version, manifest hash, package digest and NuGet.org destination. Confirm configured policy/owner rights and recheck registry absence.
5. Dispatch the workflow on main with publish=true, source_run_id=<reviewed successful preparation run>, expected_manifest_sha256=<reviewed manifest digest>. The publisher rejects PR/fork/non-main/wrong-workflow/failed/rerun/publish-source runs, incomplete metadata and expired/duplicate artifacts before download. It verifies all files/source/dependencies/manifest and registry absence before OIDC, and repeats file/registry verification immediately before pushing one exact package. It never rebuilds, uses a wildcard package glob or suppresses duplicate conflicts.
6. Retain the publisher run and verify NuGet listing, repository signature and package payload afterward. NuGet repository signing may add a signature entry, so compare reviewed contents separately from the outer signed archive hash.

No dispatch or publication is executed by this documentation. A failed preparation is retained; start a separately reviewed new preparation rather than treating a rerun as an admitted publication source. Artifact retention is30days; expired artifacts are refused. The workflow has finite job/process watchdogs, not workload performance acceptance.

## Local qualification and limits

Run the41refusal controls using the commands in AGENTS.md, full solution build/test, and `pwsh tools/check-docs.ps1 -ProjectPath . -Strict`. Synthetic control ZIP/TRX files are not product executions; network/GitHub responses are mocked and no test logs in or pushes. The separate real package rehearsal verifies the preserved local package but uses an invalid-for-hosted all-zero controller placeholder; it is not a successful GitHub preparation and cannot be selected by the publisher.

SDK10.0.301, productCore1.81.2 minima and source pin remain explicit. No engine C# changes, package/tag/version publication, API/foundation acceptance, full XSD1.1 claim, broad concurrency guarantee or performance budget is introduced by this operational route. Original package review/preparation dossiers remain immutable historical receipts.
''')
save('docs/trusted-publishing/README.md','''# Trusted-publishing workflow/controller qualification

17 November 2026. Base1783d1a99b37e206b10592c24b3a5fa3ac126969. [Pre-implementation basis](BASIS.json), [owner setup and sequence](../TRUSTED_PUBLISHING.md), [verification receipt](VERIFICATION.json), [offline verifier](verify.py).

The owner selected NuGet trusted publishing after repository metadata showed no configured Schema publishing secrets, variables, environments or publisher. This local candidate adds release.yml, a pure preparation/package verifier, same-workflow run admission guard and refusal controls; normal build CI runs those controls. Python cache ignores are housekeeping. Product C# sources, tests, framework, version rules, Core references and managed assets are unchanged.

| Qualification | Result | Scope |
|---|---|---|
| Schema Release build | Zero warnings/errors | Normal product build; no dependency change |
| Full Schema suite | 272pass/0fail/0skip | Existing249implementation+23public identities |
| Python release controls | 19pass | Synthetic package/TRX cases; payload/provenance/dependency/legal/unsafe-path/registry/workflow refusals; no login or push |
| Node provenance controls | 22pass | Mocked GitHub run/jobs/artifacts; valid source plus21refusals before outputs |
| Workflow YAML | Both files parse | Manual dispatch, defaultfalse and OIDC permission scope checked |
| PowerShell syntax | Eleven step bodies parse | Parser only; no execution of workflow push body |
| Real artifact/controller rehearsal | Pass | Preserved localalpha0.7package, nine actual Core signatures,272/23receipts,124legacy cases per lane,seal/verify andregistryGET |
| Hosted workflow run | Not performed | Candidate uncommitted/unpushed; owner settings and accepted workflow required |

The rehearsal's controller is forty zeroes, explicitly not a hosted SHA; no eligible GitHub preparation run exists. The workflow will create a new hosted artifact whose exact digest must be independently reviewed; the original local candidate remains unchanged and is not silently replaced. Source-only evidence snapshots/receipts are hashed here; raw binaries, parser dependency, ZIP/TRX/logs and rehearsal layouts remain under the ignored Core workspace packet.

No policy/variable/account change, secret/token access, login, push, tag, release, registry mutation, commit/push or publication authorization is claimed. Next: explicit commit/push/PR approval, hosted review/merge, manual preparation-only run, new exact-artifact review and explicit publication decision. User must configure the NuGet policy and profile variable before the publisher can authenticate. Full schema/profile/API/performance acceptance remains outside scope.
''')
print('Synchronized release setup, canonical docs, registry, agent instructions and handover; no account/registry action.')

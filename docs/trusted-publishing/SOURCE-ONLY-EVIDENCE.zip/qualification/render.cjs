const fs=require('fs'),path=require('path'),crypto=require('crypto');
const md=require('C:/Users/charl/AppData/Local/npm-cache/_npx/28f98e99224dac41/node_modules/markdown-it')({html:true});
const root='D:/Development/Bosak/.worktrees/Schema.TrustedPublishing';
const files=['README.md','ROADMAP.md','AGENTS.md','.kimi/HANDOVER.md','docs/ARCHITECTURE.md','docs/FEATURE_REQUESTS.md','docs/INTEGRATION.md','docs/AGENT_HANDOVER.md','docs/TRUSTED_PUBLISHING.md','docs/trusted-publishing/README.md'];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
fs.mkdirSync(path.join(__dirname,'render'),{recursive:true});let links=0,httpsLinks=0;const pages=[];
for(const file of files){
 const source=fs.readFileSync(path.join(root,file),'utf8');
 for(const token of md.parse(source,{}).flatMap(t=>[t,...(t.children||[])])){
  const link=token.type==='link_open'?token.attrGet('href'):token.type==='image'?token.attrGet('src'):null;
  if(!link||link.startsWith('#')||link.startsWith('//'))continue;
  if(/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(link)){if(link.startsWith('https://'))httpsLinks++;continue;}
  const target=path.resolve(root,path.dirname(file),decodeURIComponent(link.split('#')[0]));
  if(!fs.existsSync(target)&&target!==path.join(root,'docs/trusted-publishing/MANIFEST.json'))throw Error('Missing link '+file+': '+link);links++;
 }
 const html=md.render(source);
 fs.writeFileSync(path.join(__dirname,'render',file.replaceAll('/','_')+'.html'),'<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="file:///'+root+'/assets/css/fytala-markdown.css"></head><body>'+html+'</body></html>');
 pages.push({file,sourceLfSha256:hash(Buffer.from(source.replaceAll('\r\n','\n'))),htmlSha256:hash(Buffer.from(html))});
}
fs.writeFileSync(path.join(root,'docs/trusted-publishing/DOCUMENTATION-CHECKS.json'),JSON.stringify({pages,localDestinations:links,httpsDestinations:httpsLinks,programmaticHtmlOnly:true,nugetWebPreview:false,screenshotAcceptance:false,managedAssetsChanged:false},null,2)+'\n');
console.log('Rendered '+pages.length+' pages; checked '+links+' local destinations; '+httpsLinks+' HTTPS destinations recorded.');

from pathlib import Path
packet=Path(__file__).resolve().parent
original=packet.parent/'schema-05-package-review-20261117/render.cjs'
text=original.read_text(encoding='utf-8').replace('Schema.Release05Review','Schema.TrustedPublishing')
text=text.replace("'docs/NUGET_README.md','docs/package-0.5-review/README.md'", "'docs/TRUSTED_PUBLISHING.md','docs/trusted-publishing/README.md'")
text=text.replace('docs/package-0.5-review/','docs/trusted-publishing/')
(packet/'render.cjs').write_text(text,encoding='utf-8')

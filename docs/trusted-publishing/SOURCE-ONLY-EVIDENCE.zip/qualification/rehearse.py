from pathlib import Path
import importlib.util,json,shutil,subprocess
p=Path(__file__).parent;workspace=p.parents[1]
controller=Path(r'D:/Development/Bosak/.worktrees/Schema.TrustedPublishing')
prepared=Path(r'D:/Development/Bosak/.guard-tmp/schema-05-prepared-20261117')
old=Path(r'D:/Development/Bosak/.guard-tmp/schema-05-package-review-20261117')
source=Path(r'D:/Development/Bosak/.worktrees/Schema.Package05Prepared')
out=p/'rehearsal';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('schema_release',controller/'.github/scripts/schema_release.py');release=importlib.util.module_from_spec(spec);spec.loader.exec_module(release)
package=next((prepared/'packages').glob('*.nupkg'))
(out/'package').mkdir();shutil.copy2(package,out/'package'/package.name)
for current,target in [('source-tests','source'),('consumer-tests','consumer')]:shutil.copytree(prepared/current,out/'results'/target)
release.consumer_identity(out/'package'/package.name,prepared/'cache',prepared/'consumer/bin/Bosak.Schema.PublicConsumer.Tests/release',prepared/'consumer/obj/Bosak.Schema.PublicConsumer.Tests/project.assets.json',out/'results')
shutil.copytree(old/'legacy-baseline',out/'baseline/release')
release.legacy_check(out/'baseline/release',out/'package'/package.name,out/'results')
placeholder='0'*40
digest=release.seal(out/'package',source,release.SOURCE,release.VERSION,placeholder,out/'results')
release.verify(out/'package',source,release.SOURCE,release.VERSION,placeholder,digest)
release.registry_absent(release.VERSION)
(p/'REHEARSAL.json').write_text(json.dumps({'success':True,'manifestSha256':digest,'source':release.SOURCE,'version':release.VERSION,'packageSha256':release.digest(package.read_bytes()),'sourceCases':272,'packageCases':23,'legacyCasesPerLane':124,'realPackageAndCoreSignaturesVerified':True,'placeholderController':placeholder,'hostedPreparation':False,'eligibleForPublication':False,'registryGETOnly':True,'loginOrPushExecuted':False},indent=2)+'\n',encoding='utf-8')
print('PASS: actual prepared package/9Core signatures,272+23case receipts,124legacy controls per lane,seal/verify/GET-only preflight. Placeholder controller is not a hosted publication source.')

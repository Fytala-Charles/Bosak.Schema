from pathlib import Path
import importlib.util,json,sys
sys.path.insert(0,str(Path(__file__).parent/'yaml-parser'))
root=Path(r'D:/Development/Bosak/.worktrees/Schema.TrustedPublishing')
if importlib.util.find_spec('yaml') is None:raise SystemExit('PyYAML not installed; syntax parser unavailable')
import yaml
out=[]
for name in ['build.yml','release.yml']:
 data=yaml.load((root/'.github/workflows'/name).read_text(encoding='utf-8'),Loader=yaml.BaseLoader)
 assert isinstance(data['jobs'],dict) and isinstance(data['on'],dict)
 for job in data['jobs'].values():assert isinstance(job['steps'],list)
 if name=='release.yml':
  assert data['on']['workflow_dispatch']['inputs']['publish']['default']=='false'
  assert set(data['on'])=={'workflow_dispatch'}
  assert 'id-token' not in data['permissions'] and 'permissions' not in data['jobs']['prepare']
  assert data['jobs']['publish']['permissions']['id-token']=='write'
 out.append({'file':name,'jobs':list(data['jobs']),'parsed':True})
(Path(__file__).parent/'YAML.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('PASS: build/release YAML syntax and manual/default/permission structure.')

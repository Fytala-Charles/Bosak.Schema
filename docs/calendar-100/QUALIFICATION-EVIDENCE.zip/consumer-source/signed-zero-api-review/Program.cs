// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 November 2026
// PURPOSE              : Maps bounded calendar lexical forms to exact signed Core values.
// SPECIAL NOTES        : Part of bounded native exact calendar validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 25-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 25-11-2026     | Map signed-zero XSD years independently of the narrower Core helper |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
internal static class Program
{
    private sealed class Context(string folder) : AssemblyLoadContext(true)
    {
        /// <inheritdoc/>
        protected override Assembly? Load(AssemblyName name) { var path=Path.Combine(folder,name.Name+".dll");return File.Exists(path)?LoadFromAssemblyPath(path):null; }
    }
    private static object Inspect(string folder)
    {
        var context=new Context(folder);var assembly=context.LoadFromAssemblyPath(Path.Combine(folder,"Bosak.Schema.dll"));
        var types=assembly.GetExportedTypes();var rows=types.SelectMany(t=>t.GetMembers(BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly).Select(m=>t.FullName+"|"+m.MemberType+"|"+m.ToString()+(m is FieldInfo f&&f.IsLiteral?"="+f.GetRawConstantValue():""))).Order().ToArray();
        return new{types=types.Select(t=>t.FullName).Order().ToArray(),rows};
    }
    private static int Main(string[] args){try{Console.WriteLine(JsonSerializer.Serialize(new{before=Inspect(args[0]),after=Inspect(args[1])}));return 0;}catch(Exception error){Console.Error.WriteLine(error.ToString());return 1;}}
}

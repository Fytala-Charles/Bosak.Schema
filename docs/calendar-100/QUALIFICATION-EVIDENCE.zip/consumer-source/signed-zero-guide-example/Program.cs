// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 November 2026
// PURPOSE              : Maps bounded calendar lexical forms to exact signed Core values.
// SPECIAL NOTES        : Part of bounded native exact calendar validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 25-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 25-11-2026     | Map signed-zero XSD years independently of the narrower Core helper |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
using Bosak.XPath.Core.Xdm;
internal static class Program { private static int Main(){try{

var schema = "<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:element name='r' type='xs:dateTimeStamp'/></xs:schema>";
var options = new NativeSchemaSessionOptions(64, 32, 256, 65536, 1, 32, 1, 64, 32);
using var session = NativeSchemaSession.Create(schema, options).Value!;
using var document = session.Assess(
    "<r>2026-11-25T12:00:00.123456789123+01:00</r>",
    new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch, 0)).Value!;
var value = document.ReadRootScalar().CalendarValue;
Console.WriteLine(value.Second.ToInvariantString(64));
var utc = XdmExactCalendarValue.Parse("2026-11-25T11:00:00.123456789123Z",
    XdmExactCalendarKind.DateTimeStamp, 64, 32);
Console.WriteLine(XdmExactCalendarComparison.CompareXsd(value, utc));
return 0;}catch(Exception error){Console.Error.WriteLine(error.GetType().Name);return 1;}}}
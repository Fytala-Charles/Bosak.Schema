// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Maps bounded Gregorian fragments and exact REC timezone-aware timelines.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program { private static int Main(){try{

var options = new NativeSchemaSessionOptions(256,256,256,65536,1,256,16,256,256);
const string schema = "<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:element name='r' type='xs:gMonthDay'/></xs:schema>";
using var session = NativeSchemaSession.Create(schema,options).Value!;
using var document = session.Assess("<r>--02-29Z</r>",new(DateTimeOffset.UnixEpoch,840)).Value!;
var value = document.ReadRootScalar();
Console.WriteLine(value.Kind);
Console.WriteLine(value.GregorianYear is null);
Console.WriteLine($"{value.GregorianMonth}/{value.GregorianDay}/{value.GregorianTimezoneOffsetMinutes}");

return 0;}catch(Exception error){Console.Error.WriteLine(error.GetType().Name);return 1;}}}
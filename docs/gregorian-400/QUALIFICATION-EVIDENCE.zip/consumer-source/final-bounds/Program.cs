// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Maps bounded Gregorian fragments and exact REC timezone-aware timelines.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program
{
    private static int Main(){try{
        int count=0;var options=new NativeSchemaSessionOptions(1,0,512,65536,1,256,16,256,256);var full=new NativeSchemaSessionOptions(256,256,512,65536,1,256,16,256,256);var context=new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch,840);
        foreach(bool data in new[]{false,true})
        {
            string Schema(string kind,string facets="")=>"<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:simpleType name='T'><xs:restriction base='xs:"+kind+"'>"+facets+"</xs:restriction></xs:simpleType><xs:element name='r' type='T'/></xs:schema>";
            void Compile(string schema,NativeSchemaOutcome expected){if(data){var c=NativeSchemaNodeDataSession.Create(schema,full);if(c.Outcome!=expected)throw new Exception("compile:"+c.Outcome);c.Value?.Dispose();}else{var c=NativeSchemaSession.Create(schema,full);if(c.Outcome!=expected)throw new Exception("compile:"+c.Outcome);c.Value?.Dispose();}count++;}
            void Assess(string kind,string text,NativeSchemaOutcome expected,string facets="",bool small=false)
            {
                if(data){var c=NativeSchemaNodeDataSession.Create(Schema(kind,facets),small?options:full);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("compile:"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+text+"</r>",context);if(a.Outcome!=expected)throw new Exception("assess:"+kind+":"+a.Outcome);using var d=a.Value;if(d is not null)_=d.ReadElement([]).GregorianValue;}
                else{var c=NativeSchemaSession.Create(Schema(kind,facets),small?options:full);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("compile:"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+text+"</r>",context);if(a.Outcome!=expected)throw new Exception("assess:"+kind+":"+a.Outcome);using var d=a.Value;if(d is not null)_=d.ReadRootScalar().GregorianValue;}
                count++;
            }
            Assess("gYear",new string(' ',252)+"2000",NativeSchemaOutcome.Valid);Assess("gYear",new string(' ',253)+"2000",NativeSchemaOutcome.Unsupported);
            Assess("gYear","9223372036854775807Z",NativeSchemaOutcome.Valid,small:true);Assess("gYear","-9223372036854775807Z",NativeSchemaOutcome.Valid,small:true);Assess("gYear","-9223372036854775808",NativeSchemaOutcome.Unsupported);Assess("gYear","9223372036854775808",NativeSchemaOutcome.Unsupported);
            Assess("gMonthDay","--02-29Z",NativeSchemaOutcome.Valid,small:true);Assess("gMonthDay","--02-30Z",NativeSchemaOutcome.Invalid);Assess("gMonth","--02--",NativeSchemaOutcome.Invalid);
            Assess("gDay","---02",NativeSchemaOutcome.Invalid,"<xs:minInclusive value='---02Z'/>");Assess("gDay","---03",NativeSchemaOutcome.Valid,"<xs:minInclusive value='---02Z'/>");
            Assess("gDay","---02+12:00",NativeSchemaOutcome.Valid,"<xs:enumeration value='---01-12:00'/>");
            Compile(Schema("gYear","<xs:enumeration value='"+new string(' ',252)+"2000'/>"),NativeSchemaOutcome.Valid);Compile(Schema("gYear","<xs:enumeration value='"+new string(' ',253)+"2000'/>"),NativeSchemaOutcome.Unsupported);
            var global="<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:attribute name='a' type='xs:gDay' fixed='---01-12:00'/><xs:element name='r'><xs:complexType><xs:sequence><xs:element name='n' type='xs:decimal'/></xs:sequence><xs:attribute ref='a' fixed='---02+12:00' use='required'/></xs:complexType></xs:element></xs:schema>";Compile(global,NativeSchemaOutcome.Invalid);Compile(global.Replace("fixed='---02+12:00'","fixed='---01-12:00'"),NativeSchemaOutcome.Valid);
            foreach(var item in new[]{("float","1"),("double","1"),("duration","P1D"),("yearMonthDuration","P1M"),("dayTimeDuration","PT1S"),("gDay","---01")})
            {
                var schema=Schema(item.Item1,"<xs:minExclusive value='"+item.Item2+"'/><xs:maxExclusive value='"+item.Item2+"'/>");
                if(data){var c=NativeSchemaNodeDataSession.Create(schema,full);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("empty compile:"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+item.Item2+"</r>",context);if(a.Outcome!=NativeSchemaOutcome.Invalid||a.Value is not null)throw new Exception("empty range facts");}
                else{var c=NativeSchemaSession.Create(schema,full);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("empty compile:"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+item.Item2+"</r>",context);if(a.Outcome!=NativeSchemaOutcome.Invalid||a.Value is not null)throw new Exception("empty range facts");}count++;
            }
        }
        Console.WriteLine(count+" Gregorian package boundary controls passed");return 0;
    }catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}

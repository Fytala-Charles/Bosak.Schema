// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Parses bounded IEEE floating values and preserves primitive family identity.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program { private static int Main(){try{

var options = new NativeSchemaSessionOptions(256,256,256,65536,1,256,16,256,256);
const string schema = "<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:element name='r' type='xs:float'/></xs:schema>";
using var session = NativeSchemaSession.Create(schema,options).Value!;
using var document = session.Assess("<r>-0</r>",new(DateTimeOffset.UnixEpoch,0)).Value!;
var value = document.ReadRootScalar();
Console.WriteLine(value.Kind);
Console.WriteLine(unchecked((uint)BitConverter.SingleToInt32Bits(value.FloatValue)).ToString("X8"));

return 0;}catch(Exception error){Console.Error.WriteLine(error.GetType().Name);return 1;}}}
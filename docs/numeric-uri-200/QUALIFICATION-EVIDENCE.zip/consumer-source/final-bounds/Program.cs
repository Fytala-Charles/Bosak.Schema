// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Parses bounded IEEE floating values and preserves primitive family identity.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program
{
    private static int Main(){try{
        int count=0;
        foreach(bool data in new[]{false,true})foreach(string kind in new[]{"float","double"})
        {
            var options=new NativeSchemaSessionOptions(1,0,512,65536,1,256,16,256,256);var context=new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch,0);
            string Schema(string facets)=>"<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:simpleType name='T'><xs:restriction base='xs:"+kind+"'>"+facets+"</xs:restriction></xs:simpleType><xs:element name='r' type='T'/></xs:schema>";
            var over="<xs:enumeration value=' "+new string('1',256)+"'/>";
            var boundary="<xs:enumeration value='"+new string('1',256)+"'/>";
            if(data){var no=NativeSchemaNodeDataSession.Create(Schema(over),options);if(no.Outcome!=NativeSchemaOutcome.Unsupported)throw new Exception("raw facet cap");using var s=NativeSchemaNodeDataSession.Create(Schema(boundary),options).Value!;using var d=s.Assess("<r>"+new string('1',256)+"</r>",context).Value!;if(d.ReadElement([]).Kind!=(kind=="float"?NativeScalarKind.Float:NativeScalarKind.Double))throw new Exception("IEEE exact-decimal independence");}
            else{var no=NativeSchemaSession.Create(Schema(over),options);if(no.Outcome!=NativeSchemaOutcome.Unsupported)throw new Exception("raw facet cap");using var s=NativeSchemaSession.Create(Schema(boundary),options).Value!;using var d=s.Assess("<r>"+new string('1',256)+"</r>",context).Value!;if(d.ReadRootScalar().Kind!=(kind=="float"?NativeScalarKind.Float:NativeScalarKind.Double))throw new Exception("IEEE exact-decimal independence");}
            count+=2;
        }
        foreach(bool data in new[]{false,true})
        {
            const string schema="<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:element name='r' type='xs:anyURI'/></xs:schema>";
            var options=new NativeSchemaSessionOptions(1,0,512,65536,1,256,16,256,256);var context=new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch,0);var text=new string('a',257);
            if(data){using var s=NativeSchemaNodeDataSession.Create(schema,options).Value!;using var d=s.Assess("<r>"+text+"</r>",context).Value!;if(d.ReadElement([]).UriValue!=text)throw new Exception("URI independent bound");}
            else{using var s=NativeSchemaSession.Create(schema,options).Value!;using var d=s.Assess("<r>"+text+"</r>",context).Value!;if(d.ReadRootScalar().UriValue!=text)throw new Exception("URI independent bound");}
            count++;
        }
        Console.WriteLine(count+" package boundary controls passed");return 0;
    }catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}

// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Runs the exact package-only text normalization guide example.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program { private static int Main(){try{


var schema = """
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:simpleType name="Code">
    <xs:restriction base="xs:token"><xs:enumeration value="invoice ready"/></xs:restriction>
  </xs:simpleType>
  <xs:element name="status" type="Code"/>
</xs:schema>
""";
var options = new NativeSchemaSessionOptions(256, 256, 256, 65536, 1, 256, 16, 256, 256);
var compiled = NativeSchemaSession.Create(schema, options);
if (compiled.Outcome != NativeSchemaOutcome.Valid) throw new InvalidOperationException("Schema refused.");
using var session = compiled.Value!;
var assessed = session.Assess("<status>  invoice   ready  </status>",
    new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch, 0));
if (assessed.Outcome != NativeSchemaOutcome.Valid) throw new InvalidOperationException("Instance refused.");
using var document = assessed.Value!;
Console.WriteLine(document.ReadRootScalar().StringValue);
Console.WriteLine(document.ExportXml().Contains("  invoice   ready  "));

return 0;}catch(Exception error){Console.Error.WriteLine(error.GetType().Name);return 1;}}}
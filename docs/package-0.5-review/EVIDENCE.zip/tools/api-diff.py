from pathlib import Path
import json
p=Path(__file__).parent
a=json.loads((p/'API-BASELINE.json').read_text(encoding='utf-8'));b=json.loads((p/'API-CANDIDATE.json').read_text(encoding='utf-8'))
removed=sorted(set(a['rows'])-set(b['rows']));added=sorted(set(b['rows'])-set(a['rows']))
assert not removed,removed
types=sorted(set(b['types'])-set(a['types']))
assert types==['Bosak.Schema.NativeDecimalAssessmentContext','Bosak.Schema.NativeDecimalDiagnostic','Bosak.Schema.NativeDecimalDocument','Bosak.Schema.NativeDecimalOutcome','Bosak.Schema.NativeDecimalResult`1','Bosak.Schema.NativeDecimalSession','Bosak.Schema.NativeDecimalSessionOptions'],types
out={'baselineCommit':'c953ebe0057bea1616d3e4f891f7b0a5fc4bd99b','candidateCommit':'9fd4e6acd20b34446d736ab0ec3fa2d439f9e337','baselineTypes':len(a['types']),'candidateTypes':len(b['types']),'baselineRows':len(a['rows']),'candidateRows':len(b['rows']),'addedTypes':types,'addedRows':added,'removedOrChangedRows':removed,'sameCoreDependencies':'1.81.2','scope':'Declared public/protected reflection signatures, base/interfaces, enum values, nullable states, defaults and generic constraints; not exhaustive behavioral/binary compatibility proof'}
(p/'API-DIFF.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('No removed/changed legacy declaration rows; seven added types and35rows.')

from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
p=Path(__file__).parent;built=p/'baseline-build/bin/Bosak.Schema.Tests/release'
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
sha=lambda b:hashlib.sha256(b).hexdigest()
out={}
package=next((p/'packages').glob('*.nupkg'))
with zipfile.ZipFile(package) as z: replacement=z.read('lib/net10.0/Bosak.Schema.dll')
for name in ['legacy-baseline','legacy-candidate']:
 target=p/name
 if target.exists():raise RuntimeError('Preserve previous binary lane '+name)
 shutil.copytree(built,target)
 if name.endswith('candidate'):(target/'Bosak.Schema.dll').write_bytes(replacement)
 inventory={f.relative_to(target).as_posix():sha(f.read_bytes()) for f in target.rglob('*') if f.is_file()}
 with (p/(name+'.log')).open('wb') as log:
  run=subprocess.run(['dotnet','vstest',str(target/'Bosak.Schema.Tests.dll'),'--logger:trx','--ResultsDirectory:'+str(p/(name+'-results'))],stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert run.returncode==0,(name,run.returncode)
 cases=[]
 for f in (p/(name+'-results')).glob('*.trx'):
  tree=ET.parse(f);cases += sorted((r.attrib['testName'],r.attrib['outcome']) for r in tree.findall('.//t:UnitTestResult',ns))
 assert len(cases)==124 and all(o=='Passed' for _,o in cases),(name,len(cases))
 after={rel:sha((target/rel).read_bytes()) for rel in inventory}
 assert after==inventory,name
 out[name]={'cases':cases,'count':len(cases),'exitCode':run.returncode,'inventory':inventory,'configurationAndRetainedBinariesUnchangedAfterRun':True}
 print(name+':124passed',flush=True)
assert out['legacy-baseline']['cases']==out['legacy-candidate']['cases']
a=out['legacy-baseline']['inventory'];b=out['legacy-candidate']['inventory']
assert set(a)==set(b)
assert [rel for rel in a if a[rel]!=b[rel]]==['Bosak.Schema.dll']
out['onlyReplacement']='Bosak.Schema.dll';out['sameCaseCatalog']=True;out['packageDllSha256']=sha(replacement)
(p/'LEGACY-BINARY.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')

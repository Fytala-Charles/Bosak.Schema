from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET,re
p=Path(__file__).parent;root=Path(r'D:/Development/Bosak/.worktrees/Schema.Release05Review')
sha=lambda b:hashlib.sha256(b).hexdigest()
original=next((p/'packages').glob('*.nupkg'));staged=next((p/'staging-packages').glob('*.nupkg'))
with zipfile.ZipFile(original) as a,zipfile.ZipFile(staged) as b:
 before={name:sha(a.read(name)) for name in a.namelist()};after={name:sha(b.read(name)) for name in b.namelist()}
 changed=[name for name in before.keys()&after.keys() if before[name]!=after[name]]
 assert all(name.endswith(('.nuspec','.psmdcp')) or name in ('_rels/.rels','[Content_Types].xml') for name in changed),changed
 assert a.read('lib/net10.0/Bosak.Schema.dll')==b.read('lib/net10.0/Bosak.Schema.dll')
 assert a.read('lib/net10.0/Bosak.Schema.xml')==b.read('lib/net10.0/Bosak.Schema.xml')
 for legal in ['LICENSE.md','NOTICE']:assert a.read(legal)==b.read(legal)==(root/legal).read_bytes()
 removed=set(before)-set(after);added=set(after)-set(before)
 assert 'README.md' in removed and all(n=='README.md' or n.endswith('.psmdcp') for n in removed),removed
 assert 'NUGET_README.md' in added and all(n=='NUGET_README.md' or n.endswith('.psmdcp') for n in added),added
 assert b.read('NUGET_README.md')==(root/'docs/NUGET_README.md').read_bytes()
 doc=ET.fromstring(b.read(next(n for n in b.namelist() if n.endswith('.nuspec'))));ns={'n':doc.tag.split('}')[0][1:]}
 assert doc.findtext('n:metadata/n:readme',namespaces=ns)=='NUGET_README.md'
 assert doc.findtext('n:metadata/n:version',namespaces=ns)=='0.5.0-alpha.0.6'
 assert all(e.attrib['version']=='1.81.2' for e in doc.findall('.//n:dependency',ns))
 assets=json.loads((p/'staging-consumer/obj/Bosak.Schema.PublicConsumer.Tests/project.assets.json').read_text(encoding='utf-8'))
 assert not any(v['type']=='project' for v in assets['libraries'].values())
 core=sorted(k for k in assets['libraries'] if k.startswith('Bosak.') and not k.startswith('Bosak.Schema/'))
 assert len(core)==9 and all(k.endswith('/1.81.2') for k in core),core
 runtime=p/'staging-consumer/bin/Bosak.Schema.PublicConsumer.Tests/release'
 cache=p/'staging-cache/bosak.schema/0.5.0-alpha.0.6'
 assert (runtime/'Bosak.Schema.dll').read_bytes()==b.read('lib/net10.0/Bosak.Schema.dll')==(cache/'lib/net10.0/Bosak.Schema.dll').read_bytes()
 assert (cache/'bosak.schema.0.5.0-alpha.0.6.nupkg').read_bytes()==staged.read_bytes()
 text=b.read('NUGET_README.md').decode('utf-8')
 links=re.findall(r'\]\(([^)]+)\)',text)
 assert links and all(link.startswith('https://') for link in links)
 assert 'https://raw.githubusercontent.com/' in links[0]
 out={'file':staged.name,'bytes':staged.stat().st_size,'sha256':sha(staged.read_bytes()),'originalSha256':sha(original.read_bytes()),'originalPreserved':True,'version':'0.5.0-alpha.0.6','assemblySourceCommit':'9fd4e6acd20b34446d736ab0ec3fa2d439f9e337','packagingProvenance':'Uncommitted Directory.Build.props and docs/NUGET_README.md patch; this staging artifact is not yet an immutable committed release','runtimeAndXmlByteIdenticalToCleanCandidate':True,'onlyPackageMetadataAndReadmeChanged':True,'legalAssetsUnchanged':True,'allReadmeLinksHttps':True,'readmeLinkCount':len(links),'corePackages':core,'onlyPackageReferences':True,'archiveCacheOutputDllIdentity':True,'readmeSha256':sha(b.read('NUGET_README.md')),'signed':False,'published':False,'files':[{'path':n,'sha256':after[n]} for n in b.namelist()]}
 (p/'STAGING-PACKAGE.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('Verified staging package: exact runtime/XML/legal bytes, metadata/README-only delta, HTTPS links, fresh archive/cache/consumer identity; Core1.81.2 unchanged.')

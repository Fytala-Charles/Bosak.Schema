// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 17 November 2026
// PURPOSE              : Inventories declared public and protected assembly contracts for release review.
// SPECIAL NOTES        : Local metadata diagnostic; no product changes or registry action.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 17-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Globalization;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

if (args.Length != 3) return 2;
try
{
    var dependencies = Path.GetFullPath(args[1]);
    AssemblyLoadContext.Default.Resolving += (context, name) =>
    {
        var path = Path.Combine(dependencies, name.Name + ".dll");
        return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
    };
    var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
    var nullability = new NullabilityInfoContext();
    var rows = new SortedSet<string>(StringComparer.Ordinal);
    var types = assembly.GetExportedTypes().OrderBy(t => t.FullName, StringComparer.Ordinal).ToArray();
    const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
    string TypeName(Type t) => t.IsGenericType ? t.GetGenericTypeDefinition().FullName + "[" + string.Join(",", t.GetGenericArguments().Select(TypeName)) + "]" : t.FullName ?? t.Name;
    bool Visible(MethodBase m) => m.IsPublic || m.IsFamily || m.IsFamilyOrAssembly;
    string Parameters(MethodBase m) => string.Join(",", m.GetParameters().Select(p => TypeName(p.ParameterType) + " " + p.Name + ":" + nullability.Create(p).ReadState + (p.IsOptional ? "=" + Convert.ToString(p.DefaultValue, CultureInfo.InvariantCulture) : "")));
    foreach (var t in types)
    {
        var name = TypeName(t);
        rows.Add("T " + name + " sealed=" + t.IsSealed + " abstract=" + t.IsAbstract + " base=" + (t.BaseType is null ? "" : TypeName(t.BaseType)) + " interfaces=" + string.Join(",", t.GetInterfaces().Select(TypeName).Order(StringComparer.Ordinal)));
        foreach (var g in t.GetGenericArguments().Where(g => g.IsGenericParameter))
            rows.Add("G " + name + ":" + g.Name + " " + g.GenericParameterAttributes + " " + string.Join(",", g.GetGenericParameterConstraints().Select(TypeName)));
        foreach (var c in t.GetConstructors(flags).Where(Visible)) rows.Add("C " + name + "(" + Parameters(c) + ")");
        foreach (var m in t.GetMethods(flags).Where(m => Visible(m) && !m.IsSpecialName))
            rows.Add("M " + name + "." + m.Name + " static=" + m.IsStatic + " virtual=" + m.IsVirtual + " ->" + TypeName(m.ReturnType) + ":" + nullability.Create(m.ReturnParameter).ReadState + "(" + Parameters(m) + ")");
        foreach (var p in t.GetProperties(flags).Where(p => p.GetAccessors(true).Any(Visible)))
            rows.Add("P " + name + "." + p.Name + " " + TypeName(p.PropertyType) + ":" + nullability.Create(p).ReadState + " get=" + (p.GetMethod is not null && Visible(p.GetMethod)) + " set=" + (p.SetMethod is not null && Visible(p.SetMethod)));
        foreach (var f in t.GetFields(flags).Where(f => !f.IsSpecialName && (f.IsPublic || f.IsFamily || f.IsFamilyOrAssembly)))
            rows.Add("F " + name + "." + f.Name + " " + TypeName(f.FieldType) + " readonly=" + f.IsInitOnly + (f.IsLiteral ? "=" + Convert.ToString(f.GetRawConstantValue(), CultureInfo.InvariantCulture) : ""));
        foreach (var e in t.GetEvents(flags).Where(e => e.AddMethod is not null && Visible(e.AddMethod)))
            rows.Add("E " + name + "." + e.Name + " " + TypeName(e.EventHandlerType!));
    }
    File.WriteAllText(args[2], JsonSerializer.Serialize(new { source = args[0], assembly = assembly.GetName().FullName, types = types.Select(t => t.FullName), rows }, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine($"{types.Length} exported types; {rows.Count} declared contract rows.");
    return 0;
}
catch (Exception error)
{
    Console.Error.WriteLine(error.GetType().FullName + ": " + error.Message);
    return 1;
}

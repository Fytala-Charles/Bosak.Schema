from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
p=Path(__file__).parent;root=Path(r'D:/Development/Bosak/.worktrees/Schema.Release05Review')
package=next((p/'packages').glob('*.nupkg'))
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(package) as z:
 names=z.namelist();nuspec=next(n for n in names if n.endswith('.nuspec'));doc=ET.fromstring(z.read(nuspec));ns={'n':doc.tag.split('}')[0][1:]}
 metadata=doc.find('n:metadata',ns)
 text=lambda name:metadata.findtext('n:'+name,namespaces=ns)
 deps=[e.attrib for e in metadata.findall('.//n:dependency',ns)]
 assert text('id')=='Bosak.Schema' and text('version')=='0.5.0-alpha.0.6'
 assert {e['id'] for e in deps}=={'Bosak.XPath.Api','Bosak.XPath.Providers','Bosak.Xslt','Bosak.XQuery'}
 assert all(e['version']=='1.81.2' for e in deps),deps
 assert metadata.find('n:license',ns).text=='Apache-2.0'
 assert metadata.find('n:license',ns).attrib.get('type')=='expression'
 repository=metadata.find('n:repository',ns).attrib
 assert repository['commit']=='9fd4e6acd20b34446d736ab0ec3fa2d439f9e337',repository
 for name in ['LICENSE.md','NOTICE','README.md']:assert z.read(name)==(root/name).read_bytes(),name
 assert z.read('lib/net10.0/Bosak.Schema.dll')==(p/'source-build/bin/Bosak.Schema/release/Bosak.Schema.dll').read_bytes()
 assert z.read('lib/net10.0/Bosak.Schema.xml')==(p/'source-build/bin/Bosak.Schema/release/Bosak.Schema.xml').read_bytes()
 assert all(not n.endswith(('.pdb','.cs','.exe','.spki','.braid-license','.pem','.pfx')) for n in names)
 assert [n for n in names if n.endswith('.dll')]==['lib/net10.0/Bosak.Schema.dll']
 assert not any(n.startswith(('tools/','build/','buildTransitive/','runtimes/')) for n in names)
 out={'package':package.name,'version':text('version'),'bytes':package.stat().st_size,'sha256':sha(package.read_bytes()),'repository':repository,'dependencies':deps,'frameworks':[g.attrib for g in metadata.findall('.//n:group',ns)],'files':[{'path':name,'bytes':len(z.read(name)),'sha256':sha(z.read(name))} for name in names],'license':'Apache-2.0','legalAndReadmeMatchCleanSource':True,'dllAndXmlMatchBuild':True,'onlySchemaAssemblyBundled':True,'noBuildScriptsOrTestAssets':True,'signed':'.signature.p7s' in names,'publication':False}
 (p/'PACKAGE.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))

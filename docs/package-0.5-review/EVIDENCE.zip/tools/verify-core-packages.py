from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
p=Path(__file__).parent;cache=p/'staging-cache';runtime=p/'staging-consumer/bin/Bosak.Schema.PublicConsumer.Tests/release'
stage=json.loads((p/'STAGING-PACKAGE.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
out=[]
for identity in stage['corePackages']:
 name,version=identity.split('/');folder=cache/name.lower()/version;archive=folder/(name.lower()+'.'+version+'.nupkg')
 with zipfile.ZipFile(archive) as z:
  assert '.signature.p7s' in z.namelist(),identity
  library='lib/net10.0/'+name+'.dll';data=z.read(library)
  assert data==(folder/library).read_bytes()==(runtime/(name+'.dll')).read_bytes(),identity
  spec=ET.fromstring(z.read(next(n for n in z.namelist() if n.endswith('.nuspec'))));ns={'n':spec.tag.split('}')[0][1:]};repo=spec.find('n:metadata/n:repository',ns).attrib
  assert repo['url'].rstrip('.git')=='https://github.com/Fytala-Charles/Bosak'.rstrip('.git') and len(repo['commit'])==40
 with (p/(name+'.verify.log')).open('wb') as log:
  r=subprocess.run(['dotnet','nuget','verify','--all',str(archive)],stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert r.returncode==0,(identity,r.returncode)
 out.append({'id':name,'version':version,'source':repo,'archiveSha256':sha(archive.read_bytes()),'dllSha256':sha(data),'archiveCacheRuntimeIdentical':True,'signatureVerifyExitCode':r.returncode})
 print(identity+':signature/payload verified',flush=True)
assert len({r['source']['commit'] for r in out})==1
(p/'CORE-PACKAGES.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')

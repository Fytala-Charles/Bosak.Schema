from pathlib import Path
from urllib.request import urlopen
from urllib.error import HTTPError
from datetime import datetime,timezone
import hashlib,json
p=Path(__file__).parent
urls={'versions':'https://api.nuget.org/v3-flatcontainer/bosak.schema/index.json','candidate':'https://api.nuget.org/v3-flatcontainer/bosak.schema/0.5.0-alpha.0.6/bosak.schema.0.5.0-alpha.0.6.nupkg','stable':'https://api.nuget.org/v3-flatcontainer/bosak.schema/0.5.0/bosak.schema.0.5.0.nupkg'}
results=[]
for name,url in urls.items():
 try:
  with urlopen(url,timeout=30) as r: status=r.status;data=r.read();headers=dict(r.headers)
 except HTTPError as e:status=e.code;data=e.read();headers=dict(e.headers)
 (p/('REGISTRY-'+name+'.body')).write_bytes(data)
 result={'name':name,'url':url,'status':status,'observedUtc':datetime.now(timezone.utc).isoformat(),'bodySha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if name=='versions' and status==200:result['versions']=json.loads(data)['versions']
 results.append(result)
(p/'REGISTRY.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))

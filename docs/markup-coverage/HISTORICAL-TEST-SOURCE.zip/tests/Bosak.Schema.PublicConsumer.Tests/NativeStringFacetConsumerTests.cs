// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 November 2026
// PURPOSE              : Tests bounded named string facet assessment through the public owned scalar facade.
// SPECIAL NOTES        : Bounded native decimal profile; published Core 1.81.2; no general XSD conformance claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 26-11-2026     | Verify measured text admissions with original fixture bytes unchanged |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Globalization;
using System.Numerics;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.Schema;
using Xunit;

namespace Bosak.Schema.PublicConsumer.Tests;

/// <summary>Exercises named string Unicode length, enumeration, capacity and detached lifetime.</summary>
public sealed class NativeStringFacetConsumerTests
{
    /// <summary>Gets stable authored string facet cases.</summary>
    /// <returns>Case identity and payload pairs.</returns>
    public static IEnumerable<object[]> Cases()
    {
        using var input=JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"TestData","StringFacets","m2d1-cases.json")));
        foreach(var row in input.RootElement.EnumerateArray())yield return [row.GetProperty("id").GetString()!,row.GetRawText()];
    }
    private static string Text(NativeScalarValue value)=>value.Kind switch
    {
        NativeScalarKind.String=>value.StringValue,
        NativeScalarKind.Decimal=>value.DecimalValue.ToInvariantString(256),
        NativeScalarKind.Boolean=>value.BooleanValue?"true":"false",
        NativeScalarKind.Integer=>value.IntegerValue.ToString(CultureInfo.InvariantCulture),
        _=>throw new NotSupportedException()
    };
    /// <summary>Checks exact values, complete failures, lexical export/reopen and detached lifetime.</summary>
    /// <param name="id">Stable authored case ID.</param>
    /// <param name="payload">Schema, instance and exact expectations.</param>
    [Theory][MemberData(nameof(Cases))]
    public void StringFacetAssessment_SeparatesValidityCapacityAndProfile(string id,string payload)
    {
        Assert.StartsWith("M2D1-",id);using var data=JsonDocument.Parse(payload);var row=data.RootElement;
        var options=new NativeSchemaSessionOptions(256,256,row.GetProperty("maxStringCharacters").GetInt32(),65536,1,8,1,256,256);
        if(id is "M2D1-47" or "M2D1-48" or "M2D1-49" or "M2D1-50" or "M2D1-51" or "M2D1-52" or "M2D1-53" or "M2D1-57" or "M2D1-58" or "M2D1-59" or "M2D1-60" or "M2D1-61" or "M2D1-62" or "M2D1-63" or "M2D1-64" or "M2D1-67" or "M2D1-69" or "M2D1-70")
        {
            var valid=id is "M2D1-64" or "M2D1-67" or "M2D1-69" or "M2D1-70";
            NativeTextLegacyVerification.Check(row.GetProperty("schema").GetString()!,row.GetProperty("instance").GetString()!,options,valid?NativeSchemaOutcome.Valid:NativeSchemaOutcome.Invalid,NativeSchemaOutcome.Valid,"abc");return;
        }
        var created=NativeSchemaSession.Create(row.GetProperty("schema").GetString()!,options);
        Assert.Equal(row.GetProperty("expectedCompile").GetString(),created.Outcome.ToString());
        if(created.Outcome!=NativeSchemaOutcome.Valid)
        {
            Assert.Null(created.Value);Assert.Equal("BSK-NATIVE-SCHEMA-UNSUPPORTED",Assert.Single(created.Diagnostics).Code);
            Assert.Equal(row.GetProperty("unsupportedReason").GetString(),created.Diagnostics[0].UnsupportedReason.ToString());return;
        }
        using var s=created.Value!;var context=new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch,0);var xml=row.GetProperty("instance").GetString()!;
        var assessed=s.Assess(xml,context);Assert.Equal(row.GetProperty("expectedAssessment").GetString(),assessed.Outcome.ToString());
        if(assessed.Outcome!=NativeSchemaOutcome.Valid)
        {
            Assert.Null(assessed.Value);Assert.Single(assessed.Diagnostics);
            Assert.Equal("BSK-NATIVE-INSTANCE-"+assessed.Outcome.ToString().ToUpperInvariant(),assessed.Diagnostics[0].Code);
            if(assessed.Outcome==NativeSchemaOutcome.Unsupported)Assert.Equal(row.GetProperty("unsupportedReason").GetString(),assessed.Diagnostics[0].UnsupportedReason.ToString());return;
        }
        using var doc=assessed.Value!;var values=row.GetProperty("values").EnumerateArray().ToArray();Assert.Equal(values.Length,doc.ScalarCount);var detached=new List<NativeScalarValue>();
        for(int i=0;i<values.Length;i++)
        {
            var v=doc.ReadScalar(i);detached.Add(v);Assert.Equal(values[i].GetProperty("kind").GetString(),v.Kind.ToString());Assert.Equal(values[i].GetProperty("value").GetString(),Text(v));
            if(v.Kind==NativeScalarKind.Integer)
            {
                Assert.Equal(BigInteger.Parse(values[i].GetProperty("value").GetString()!,CultureInfo.InvariantCulture),v.IntegerValue);
                Assert.Throws<InvalidOperationException>(()=>v.StringValue);Assert.Throws<InvalidOperationException>(()=>v.DecimalValue);Assert.Throws<InvalidOperationException>(()=>v.BooleanValue);
            }
            else Assert.Throws<InvalidOperationException>(()=>v.IntegerValue);
        }
        var exported=doc.ExportXml();Assert.True(XNode.DeepEquals(XDocument.Parse(xml,LoadOptions.PreserveWhitespace).Root,XDocument.Parse(exported,LoadOptions.PreserveWhitespace).Root));
        doc.Dispose();using var reopened=s.Assess(exported,context).Value!;Assert.Equal(values.Length,reopened.ScalarCount);
        for(int i=0;i<values.Length;i++)Assert.Equal(Text(detached[i]),Text(reopened.ReadScalar(i)));
        s.Dispose();Assert.Throws<ObjectDisposedException>(()=>reopened.ReadScalar(0));foreach(var v in detached)Assert.NotNull(Text(v));
    }

    /// <summary>Old decimal APIs retain named string refusal while opt-in supports string facets.</summary>
    [Fact]
    public void LegacyDecimal_RemainsDecimalOnly()
    {
        const string schema="<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:simpleType name='Label'><xs:restriction base='xs:string'><xs:length value='1'/></xs:restriction></xs:simpleType><xs:element name='r'><xs:complexType><xs:sequence><xs:element name='s' type='Label'/></xs:sequence></xs:complexType></xs:element></xs:schema>";
        var old=NativeDecimalSession.Create(schema,new(256,256,1,4,1,256,256));Assert.Equal(NativeDecimalOutcome.Unsupported,old.Outcome);Assert.Null(old.Value);
        using var session=NativeSchemaSession.Create(schema,new(1,0,2,65536,1,4,1,1,0)).Value!;
        using var doc=session.Assess("<r><s>😀</s></r>",new(DateTimeOffset.UnixEpoch,0)).Value!;Assert.Equal("😀",doc.ReadScalar(0).StringValue);
    }
}

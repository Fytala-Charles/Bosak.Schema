from pathlib import Path
import sys, shutil, json
sys.path.insert(0, 'D:/Development/Bosak/.worktrees/Schema.BetaRelease/.github/scripts')
import schema_release as c
root=Path('D:/Development/Bosak'); p=root/'.guard-tmp/schema-beta1-20261117'
package=p/'package'/f'Bosak.Schema.{c.VERSION}.nupkg'; results=p/'results'
c.consumer_identity(package,p/'cache',p/'consumer/bin/Bosak.Schema.PublicConsumer.Tests/release',p/'consumer/obj/Bosak.Schema.PublicConsumer.Tests/project.assets.json',results)
old=root/'.guard-tmp/schema-05-package-review-20261117'
inventory=lambda folder:{f.relative_to(folder).as_posix():c.digest(f.read_bytes()) for f in folder.rglob('*') if f.is_file()}
assert inventory(old/'legacy-baseline')==c.read_json(old/'LEGACY-BINARY.json')['legacy-baseline']['inventory']
for name,original,published in [('legacy',old/'legacy-baseline',False),('published',root/'.guard-tmp/schema-publication-20261117/consumer/bin/Bosak.Schema.PublicConsumer.Tests/release',True)]:
    baseline=p/'baselines'/name/'release'
    assert not baseline.exists()
    shutil.copytree(original,baseline)
    c.legacy_check(baseline,package,results,published)
    assert inventory(original)==inventory(baseline)
    print(name+' retained control/replacement passed',flush=True)
old=root/'.guard-tmp/schema-publication-20261117'
c.consumer_identity(old/'Bosak.Schema.0.5.0-alpha.0.7.nupkg',old/'cache',p/'baselines/published/release',old/'consumer/obj/Bosak.Schema.PublicConsumer.Tests/project.assets.json',results,True)
manifest=c.seal(p/'package',p/'source',c.SOURCE,c.VERSION,'0'*40,results)
c.verify(p/'package',p/'source',c.SOURCE,c.VERSION,'0'*40,manifest)
c.registry_absent(c.VERSION)
c.save(p/'REHEARSAL.json',{'localOnly':True,'hostedPreparation':False,'publicationAuthorized':False,'remoteTagPushed':False,'manifestSha256':manifest,'package':c.package_info(package,p/'source',c.SOURCE,c.VERSION),'tag':c.TAG,'source':c.SOURCE})
print('PASS: local beta package sealed/verified; registry absent. Manifest '+manifest)

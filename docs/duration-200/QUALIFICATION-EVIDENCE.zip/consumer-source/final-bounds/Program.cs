// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 November 2026
// PURPOSE              : Represents bounded exact duration months and seconds with REC partial ordering.
// SPECIAL NOTES        : Part of bounded native datatype validation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.Schema;
internal static class Program
{
    private static int Main(){try{
        int count=0;
        foreach(bool data in new[]{false,true})
        {
            string Schema(string facets="")=>"<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'><xs:simpleType name='T'><xs:restriction base='xs:duration'>"+facets+"</xs:restriction></xs:simpleType><xs:element name='r' type='T'/></xs:schema>";
            var context=new NativeSchemaAssessmentContext(DateTimeOffset.UnixEpoch,0);
            void Assess(string text,NativeSchemaOutcome expected,int digits=256,int scale=256,string facets="")
            {
                var options=new NativeSchemaSessionOptions(digits,scale,512,65536,1,256,16,256,256);
                if(data){var c=NativeSchemaNodeDataSession.Create(Schema(facets),options);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("compile"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+text+"</r>",context);if(a.Outcome!=expected)throw new Exception("assess"+a.Outcome);using var d=a.Value;if(d is not null)_=d.ReadElement([]).DurationSeconds;}
                else{var c=NativeSchemaSession.Create(Schema(facets),options);if(c.Outcome!=NativeSchemaOutcome.Valid)throw new Exception("compile"+c.Outcome);using var s=c.Value!;var a=s.Assess("<r>"+text+"</r>",context);if(a.Outcome!=expected)throw new Exception("assess"+a.Outcome);using var d=a.Value;if(d is not null)_=d.ReadRootScalar().DurationMonths;}
                count++;
            }
            var raw="P"+new string('0',253)+"1D";Assess(raw,NativeSchemaOutcome.Valid);Assess(" "+raw,NativeSchemaOutcome.Unsupported);
            Assess("PT1S",NativeSchemaOutcome.Valid,digits:1);Assess("PT01S",NativeSchemaOutcome.Unsupported,digits:1);
            Assess("P1Y",NativeSchemaOutcome.Valid,digits:2);Assess("P9Y",NativeSchemaOutcome.Unsupported,digits:2);
            Assess("PT0.1S",NativeSchemaOutcome.Valid,scale:1);Assess("PT0.10S",NativeSchemaOutcome.Unsupported,scale:1);
            Assess("P146097D",NativeSchemaOutcome.Unsupported,facets:"<xs:minInclusive value='P400Y'/>");
            Assess("P146097D",NativeSchemaOutcome.Invalid,facets:"<xs:enumeration value='P400Y'/>");
            Assess("-P146097000D",NativeSchemaOutcome.Unsupported,facets:"<xs:minInclusive value='-P400000Y'/>");
            Assess("-P146096999D",NativeSchemaOutcome.Valid,facets:"<xs:minInclusive value='-P400000Y'/>");
            var options=new NativeSchemaSessionOptions(256,256,512,65536,1,256,16,256,256);var over=Schema("<xs:enumeration value=' "+raw+"'/>");
            if(data){var c=NativeSchemaNodeDataSession.Create(over,options);if(c.Outcome!=NativeSchemaOutcome.Unsupported)throw new Exception("raw facet limit");}
            else{var c=NativeSchemaSession.Create(over,options);if(c.Outcome!=NativeSchemaOutcome.Unsupported)throw new Exception("raw facet limit");}count++;
        }
        Console.WriteLine(count+" duration package boundary controls passed");return 0;
    }catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}
